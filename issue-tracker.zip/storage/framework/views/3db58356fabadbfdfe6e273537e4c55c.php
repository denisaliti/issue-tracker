

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3"><?php echo e($project->name); ?></h1>
        <p class="text-muted"><?php echo e($project->description); ?></p>
        <?php if($project->start_date): ?>
            <small class="text-muted"><i class="bi bi-calendar"></i> Start: <?php echo e($project->start_date); ?> | Deadline: <?php echo e($project->deadline ?? 'N/A'); ?></small>
        <?php endif; ?>
    </div>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('projects.issues.create', $project)); ?>" class="btn btn-primary"><i class="bi bi-plus"></i> New Issue</a>
        <a href="<?php echo e(route('projects.edit', $project)); ?>" class="btn btn-outline-secondary">Edit</a>
    </div>
</div>

<div class="card">
    <div class="card-header">Issues (<?php echo e($project->issues->count()); ?>)</div>
    <div class="card-body">
        <?php if($project->issues->isEmpty()): ?>
            <p class="text-muted">No issues yet.</p>
        <?php else: ?>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Status</th>
                        <th>Priority</th>
                        <th>Tags</th>
                        <th>Assigned To</th>
                        <th>Due Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $project->issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('projects.issues.show', [$project, $issue])); ?>"><?php echo e($issue->title); ?></a></td>
                        <td><span class="badge badge-<?php echo e($issue->status); ?>"><?php echo e($issue->status); ?></span></td>
                        <td><span class="badge badge-<?php echo e($issue->priority); ?>"><?php echo e($issue->priority); ?></span></td>
                        <td>
                            <?php $__currentLoopData = $issue->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge" style="background-color: <?php echo e($tag->color ?? '#6c757d'); ?>"><?php echo e($tag->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <?php $__currentLoopData = $issue->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-secondary"><?php echo e($user->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($issue->due_date ?? '-'); ?></td>
                        <td>
                            <a href="<?php echo e(route('projects.issues.edit', [$project, $issue])); ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                            <form action="<?php echo e(route('projects.issues.destroy', [$project, $issue])); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-outline-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\issue-tracker\resources\views/projects/show.blade.php ENDPATH**/ ?>