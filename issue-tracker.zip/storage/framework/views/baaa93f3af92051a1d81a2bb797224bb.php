

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3"><?php echo e($project->name); ?></h1>
        <p class="text-muted mb-1"><?php echo e($project->description); ?></p>
        <?php if($project->start_date): ?>
            <small class="text-muted"><i class="bi bi-calendar"></i> Start: <?php echo e($project->start_date); ?> | Deadline: <?php echo e($project->deadline ?? 'N/A'); ?></small>
        <?php endif; ?>
    </div>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('projects.issues.create', $project)); ?>" class="btn btn-primary"><i class="bi bi-plus"></i> New Issue</a>
        <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->id() === $project->user_id): ?>
                <a href="<?php echo e(route('projects.edit', $project)); ?>" class="btn btn-outline-secondary">Edit Project</a>
                <form action="<?php echo e(route('projects.destroy', $project)); ?>" method="POST" onsubmit="return confirm('Are you sure?')">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-outline-danger">Delete Project</button>
                </form>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-2">
            <div class="col-md-3">
                <select name="status" class="form-select">
                    <option value="">All Statuses</option>
                    <option value="open" <?php echo e(request('status') == 'open' ? 'selected' : ''); ?>>Open</option>
                    <option value="in_progress" <?php echo e(request('status') == 'in_progress' ? 'selected' : ''); ?>>In Progress</option>
                    <option value="closed" <?php echo e(request('status') == 'closed' ? 'selected' : ''); ?>>Closed</option>
                </select>
            </div>
            <div class="col-md-3">
                <select name="priority" class="form-select">
                    <option value="">All Priorities</option>
                    <option value="low" <?php echo e(request('priority') == 'low' ? 'selected' : ''); ?>>Low</option>
                    <option value="medium" <?php echo e(request('priority') == 'medium' ? 'selected' : ''); ?>>Medium</option>
                    <option value="high" <?php echo e(request('priority') == 'high' ? 'selected' : ''); ?>>High</option>
                </select>
            </div>
            <div class="col-md-3">
                <select name="tag" class="form-select">
                    <option value="">All Tags</option>
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tag->id); ?>" <?php echo e(request('tag') == $tag->id ? 'selected' : ''); ?>><?php echo e($tag->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-outline-primary w-100">Filter</button>
            </div>
        </form>
    </div>
</div>

<?php if($issues->isEmpty()): ?>
    <div class="alert alert-info">No issues found.</div>
<?php else: ?>
    <div class="card">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Status</th>
                    <th>Priority</th>
                    <th>Tags</th>
                    <th>Due Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $issues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="<?php echo e(route('projects.issues.show', [$project, $issue])); ?>"><?php echo e($issue->title); ?></a></td>
                    <td><span class="badge badge-<?php echo e($issue->status); ?>"><?php echo e($issue->status); ?></span></td>
                    <td><span class="badge badge-<?php echo e($issue->priority); ?>"><?php echo e($issue->priority); ?></span></td>
                    <td>
                        <?php $__currentLoopData = $issue->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge" style="background-color: <?php echo e($tag->color ?? '#6c757d'); ?>"><?php echo e($tag->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td><?php echo e($issue->due_date ?? '-'); ?></td>
                    <td>
                        <a href="<?php echo e(route('projects.issues.edit', [$project, $issue])); ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                        <form action="<?php echo e(route('projects.issues.destroy', [$project, $issue])); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\issue-tracker\resources\views/issues/index.blade.php ENDPATH**/ ?>