

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3">Projects</h1>
    <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus"></i> New Project
    </a>
</div>

<?php if($projects->isEmpty()): ?>
    <div class="alert alert-info">No projects yet. Create your first one!</div>
<?php else: ?>
    <div class="row">
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($project->name); ?></h5>
                    <p class="card-text text-muted"><?php echo e(Str::limit($project->description, 100)); ?></p>
                    <p class="card-text"><small class="text-muted"><?php echo e($project->issues_count); ?> issues</small></p>
                    <?php if($project->deadline): ?>
                        <p class="card-text"><small class="text-muted"><i class="bi bi-calendar"></i> Deadline: <?php echo e($project->deadline); ?></small></p>
                    <?php endif; ?>
                </div>
                <div class="card-footer d-flex gap-2">
                    <a href="<?php echo e(route('projects.issues.index', $project)); ?>" class="btn btn-sm btn-outline-primary">View</a>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->id() === $project->user_id): ?>
                            <a href="<?php echo e(route('projects.edit', $project)); ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                            <form action="<?php echo e(route('projects.destroy', $project)); ?>" method="POST" onsubmit="return confirm('Are you sure?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-outline-danger">Delete</button>
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\issue-tracker\resources\views/projects/index.blade.php ENDPATH**/ ?>